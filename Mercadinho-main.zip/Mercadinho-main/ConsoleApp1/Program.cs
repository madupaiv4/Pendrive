﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        //class Produtos
        //{
        //    public string Codigo;
        //    public string Descricao;
        //    public int Preco;
        //    public int Unidades;

        //    public void Dados(string codigo, string descricao, int preco, int unidades)
        //    {
        //        Codigo = codigo;
        //        Descricao = descricao;
        //        Preco = preco;
        //        Unidades = unidades;

        //    }
        //}
  

        class Produtos
        {
            public string Codigo { get; set; }
            public string Descricao { get; set; }
            public int Preco { get; set; }
            public int Quantidade { get; set; }
            public string Unidades { get; set; }


            public string DadosFormatados()
            {

                return String.Format($"| {Codigo, -13} | {Descricao, -18} | {Preco, 10:C} | {Quantidade,7:F2} {Unidades, -4}|");
            }


        }
        static void Main(string[] args)
        {
            Console.WriteLine("-----------------------------------------------------------------");
            Console.WriteLine("|    Código     |     descrição      | Preço (R$) | Quant.Estoque |");
            Console.WriteLine("-----------------------------------------------------------------");

            Produtos prod1 = new Produtos()
            {
                Codigo = "7891025101604", Descricao = "Leite", Preco = 3, Quantidade = 15, Unidades = "l"
            };
            Console.WriteLine(prod1.DadosFormatados());
        }
    }
}
